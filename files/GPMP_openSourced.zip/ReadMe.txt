# Python 3.6

Used packages: 
numpy 1.19.5;
matplotlib 3.3.4;
autograd 1.4;
scipy 1.5.4;
pylasadataset 0.1.1