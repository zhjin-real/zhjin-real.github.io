Requirements for running the open-sourced project:
1. python with version 3.7
2. numpy with version 1.21.6
2. cvxopt with version 1.3.0
3. autograd with version 1.5
4. scipy with version 1.7.3
5. matplotlib with verison 3.5.3
6. pylasadataset with version 0.1.1

Contact Information: jzhzjut@outlook.com
